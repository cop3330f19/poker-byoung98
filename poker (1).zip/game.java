package poker;

import java.util.*;
import java.util.Scanner;

public class game{
     private int card1, card2, card3, card4, card5;
     private char suit1, suit2, suit3, suit4, suit4, suit5;
     
     private int [][] pokerGame = new int [4] [13];
    
     //create 2-dimension array
     
     
     public game(int card1,int card2, int card2, int card3, int card4,
                 int card4, int card5, char suit1, char suit2, char suit3, char suit4,
                char suit4, char suit5){
          
          this.card1 = card1;
          this.card2 = card2;
          this.card3 = card3;
          this.card4 = card4;
          this.card5 = card5;
          
          this.suit1 = suit1;
          this.suit2 = suit2;
          this.suit3 = suit3;
          this.suit4 = suit4;
          this.suit5 = suit5;
     }          
}
//create scanner
Scanner input = new Scanner(System.in);

//creat a 2 dim array
public void loadArray(){
for(int i = 0; i<4; i++){
   for(int a = 0; a<13; a++){

        pokerGame[i][a] = 0;
       }
   }
}

public  void insertRankSuit (char suit, int rank){
//hearts,spades,diamonds, jack
int suiter;
    if (suit == 'H' || suit == 'h')
    suiter = 0;
    
     if (suit == 'S' || suit == 's')
          suiter = 1;
     
     if(suit == 'D' || suit == 'd')
          suiter = 2;
     
     if(suit == 'J' || suit == 'j')
          suiter = 3;
     
     //insert into array
      pokerGame[rank][suiter] = 1;  
     
}


public void checkHand(int [][] array){
     int count = 0;
     for(int x = 0; x <4; x++){
          for(int y = 0; y< 13; y++){
             //flush 
            if(array[x][y] == 1)
                 count++;
               if(x )
                    
            
                    
                     
          }
     }
     
}




//flush
//all cards have the same suit

//straight
//consecutive ranks
//ace can come either before 2/after king

//straight flush

//four of a kind

//full house
//3 cards of one rank 
//two cards of another rank

//three of a kind

//two pair 

//one pair 

//none of the above

