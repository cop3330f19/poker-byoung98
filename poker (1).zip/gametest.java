import java.util.*;
import java.util.Scanner;

 public gametest{
public static void main(String[]args){
     
     
   int card1;
   int card2;
   int card3;
   int card4;
   int card5;
          
   char suit1;
   char suit2;
   char suit3;
   char suit4;
   char suit5;
    
     
     
     game temp = new game(card1,card2,card3,card4,card5,suit1,suit2,suit3,suit4,suit5);
     
     Scanner input = new Scanner(System.in);
     
     
     System.out.println("card1:");
     card1 = input.nextInt();
     
     
     System.out.println("card2:");
     card2 = input.nextInt();
     
     System.out.println("card3:");
     card3 = input.nextInt();
     
     System.out.println("card4:");
     card4 = input.nextInt();
     
     System.out.println("card5:");
     card5 = input.nextInt();
     
     System.out.println("suit1:");
     suit1 = input.next().charAt(0); 
     
     System.out.println("suit2:");
     suit2 = input.next().charAt(0); 
     
     System.out.println("suit3:");
     suit3 = input.next().charAt(0); 
     
     System.out.println("suit4:");
     suit4 = input.next().charAt(0); 
     
     System.out.println("suit5:");
     suit5 = input.next().charAt(0); 
     
     insertRankSuit (suit1,rank1);
     insertRankSuit (suit2,rank2);
     insertRankSuit (suit3,rank3);
     insertRankSuit (suit4,rank4);
     insertRankSuit (suit5,rank5);
     
     
    }
}